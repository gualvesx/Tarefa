//atividade 2
//botão
function somar(a, b) {
    return a + b;
}
console.log(somar(5, 3));
