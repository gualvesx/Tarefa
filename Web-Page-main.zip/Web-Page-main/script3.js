function notif() {
    alert('Quem piscar nunca mais podera ver dorama!');
}
