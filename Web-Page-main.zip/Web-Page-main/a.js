function a() {
    alert('Eu aprendi a modificar a página html por Js e aprendi sobre variáveis e o console.');
}

