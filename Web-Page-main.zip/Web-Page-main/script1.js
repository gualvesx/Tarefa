//atividade 1
var nome = 'Gu';
var idade = 16;
var ativo = true;

console.log ("Nome: ", nome);
console.log ("Idade: ", idade);
console.log ("Ativo: ", ativo);
//mudar titulo
const titulo = document.getElementById('title');
titulo.textContent = 'Título modificado com JS!';
